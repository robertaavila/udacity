## Fresh tomatoes 

O pacote fresh tomatoes � composto por 4 arquivos, 1 html e 3 em python. Os arquivos em python s�o: media (no qual � definida a classe Movie), fresh_tomatoes (que utiliza python para sobrepor as informa��es da p�gina em html fresh_tomatoes) e entertainment_center (no qual s�o definidas as inst�ncias de Movie e � dado o comando para utilizar as informa��es dos demais arquivos). 

## Como utilizar 

Para utilizar o pacote abra o arquivo entertainment_center e pressione F5. Ser� aberta uma p�gina de html com a estrutura b�sica da p�gina fresh_tomatoes.html e as informa��es dos demais arquivos. Dessa forma, a p�gina que antes se chamava Fresh Tomatoes! agora se chamar� Tom Hanks S2 e ter� 6 cartazes de filmes do ator. Ao clicar nos cartazes o respectivo trailer � exibido no centro da p�gina.   

## Fonte

Os arquivos originais foram fornecidos como parte do curso Introdu��o � Programa��o da Udacity. 